package zad1;

import java.awt.FlowLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;

public class Database extends JFrame{

	public static final String DRIVER = "org.apache.derby.JDBC.EmbeddedDriver";
	private String jdbcURL;
	private TravelData travelData;
	
	public Database(String url, TravelData td) {
		
		super("Baza danych ofert");
		this.jdbcURL = url;
		this.travelData = td;
		this.setLocationRelativeTo(null);
		this.setBounds(100, 100, 500, 500);
		
		MyTableModel mtm = new MyTableModel(this);
		JTable tab = new JTable(mtm);
		JScrollPane sp = new JScrollPane(tab);
		JButton pl = new JButton("Polski");
		JButton en = new JButton("English");
		this.setLayout(new FlowLayout());
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.add(sp);
		this.add(pl);
		this.add(en);
		//this.setVisible(true);
	}
	
	public String getJdbcURL() {
		
		return this.jdbcURL;
		
	}
	
	public TravelData getTravelData() {
		
		return this.travelData;
		
	}
	
	public void create() {
		
				
		try {
		Connection connection = DriverManager.getConnection(this.getJdbcURL());
		//connection.createStatement().execute("drop table offers");
		connection.createStatement().execute("create table offers(offer varchar(200))");
		
		for (String offer : this.getTravelData().getRawOffersDescriptionsList()) {
			
			connection.createStatement().execute("insert into offers values('" + offer + "')");
			
		}
		
		//System.out.println("Utworzono bazę danych ofert.");
	
		connection.close();
		
		} catch (Exception exc) {
			System.out.println(exc.getMessage());
		}
			
	}
	
	public void showGui() {
		
		this.setVisible(true);
		
	}
	
	class MyTableModel extends AbstractTableModel {
		
		private Database db;
		
		public MyTableModel(Database db) {
			this.db=db;
		}
		
		public Database getDatabase() {
			return this.db;
		}

		public String getColumnName(int column) {
			return "---";
		}
		
		
		public int getRowCount() {
			// TODO Auto-generated method stub
			try {
				int rowCount=0;
				Connection connection = DriverManager.getConnection(this.getDatabase().getJdbcURL());
			
				ResultSet rs = connection.createStatement().executeQuery("select * from offers");
				
				while (rs.next()) {
						rowCount++;
					}
				
				rs.close();
				connection.close();
				return rowCount;
				} catch (Exception exc) {
					System.out.println(exc.getMessage());
					return 0;
				}
		}

		public int getColumnCount() {
			// TODO Auto-generated method stub
			return 1;
		}

		public Object getValueAt(int arg0, int arg1) {
			// TODO Auto-generated method stub
			try {
				String rawOffer;
				Connection connection = DriverManager.getConnection(this.getDatabase().getJdbcURL());
				ResultSet rs = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                        ResultSet.CONCUR_READ_ONLY).executeQuery("select * from offers");
				rs.absolute(arg0+1);
				rawOffer = rs.getString(arg1+1);
				rs.close();
				connection.close();
				return TravelData.processOffer(rawOffer, "en_GB", "yyyy-mm-dd");
				} catch (Exception exc) {
					System.out.println(exc.getMessage());
					return "";
				}
		}
		
	}
	
	
}
