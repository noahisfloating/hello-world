package zad1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class TravelData {
	
	private File dataDirectory;
	
	public static Locale[] loc = Locale.getAvailableLocales();
	
	public TravelData(File dataDirectory) {
		this.dataDirectory = dataDirectory;
	}
	
	public File getDataDirectory() {
		return dataDirectory;
	}
	
	public void setDataDirectory(File dataDirectory) {
		this.dataDirectory = dataDirectory;		
	}
	
	public List<String> getOffersDescriptionsList(String locale, String dateFormat) {
		
		ArrayList<String> offers = new ArrayList<String>();
		
		for (String s : getRawOffersDescriptionsList()) {
			offers.add(processOffer(s, locale, dateFormat));
		}
		
		return offers;
		
	}
	
	public List<String> getOffersDescriptionsList(ArrayList<String> rawOffersDescriptionList, String locale, String dateFormat) {
		
		ArrayList<String> offers = new ArrayList<String>();
		
		for (String s : rawOffersDescriptionList) {
			offers.add(processOffer(s, locale, dateFormat));
		}
		
		return offers;
		
	}
	
	public List<String> getRawOffersDescriptionsList() {
		
		try {
			
			File[] offersInDataDirectory = getDataDirectory().listFiles();
			String rawOffer;
			ArrayList<String> rawOffers = new ArrayList<String>();
			for (File f : offersInDataDirectory) {
				FileReader fr = new FileReader(f);
				BufferedReader br = new BufferedReader(fr);
				while ((rawOffer = br.readLine()) != null) {
					rawOffers.add(rawOffer.trim());
				}
				br.close();
				fr.close();				
				}
			return rawOffers;				
		} catch (Exception exc) {
			System.out.println("Wystąpił problem z odczytem plików z ofertami.");
			return null;
		}
	}
	
	public static String processOffer(String rawOffer, String locale, String dateFormat) {
		
		String[] offerParametres = rawOffer.split("\t");
		String initialLocale = offerParametres[0];
		StringBuilder sb = new StringBuilder();
		
		String inputCountry = offerParametres[1];
		String outputCountry = "";
		
		String inputDestination = offerParametres[4];
		String outputDestination = "";
		
		String inputPrice = offerParametres[5];
		Double inputPriceParsed = new Double(0);
		String outputPrice = "";
		
		try {
			outputCountry = TravelData.translateCountry(initialLocale, locale, inputCountry);
		} catch (Exception exc) {
			System.out.println("Wystąpił problem z parsowaniem nazwy kraju.");
		}
		
		sb.append(outputCountry + " ");
		
		for (int i=2; i<4; i++) {
			sb.append(TravelData.formatDate("yyyy-mm-dd", dateFormat, offerParametres[i]));
			sb.append(" ");
		}
		
		try {
			outputDestination = TravelData.translateDestination(initialLocale, locale, inputDestination);
		} catch (MissingResourceException exc) {
			System.out.println(exc.getMessage());
		}
		
		sb.append(outputDestination);
		sb.append(" ");
		
		sb.append(TravelData.formatPrice(initialLocale, locale, offerParametres[5]));
		sb.append(" ");
		
		sb.append(outputPrice+" ");
		sb.append(offerParametres[6]);
		
		return sb.toString().trim();
		
	}
	
	public static String translateCountry(String localeFrom, String localeTo, String toBeTranslated) {
		
		HashMap mapFrom = new HashMap();
		String country;
		Locale parsedLocale;
		
		for (int i=0; i<loc.length; i++) {
			mapFrom.put(loc[i].getDisplayCountry(validateLocale(localeFrom)), loc[i]);
		}
		
		parsedLocale = (Locale) mapFrom.get(toBeTranslated);
		return parsedLocale.getDisplayCountry(validateLocale(localeTo));
				
	}
	
	public static String translateDestination(String localeFrom, String localeTo, String toBeTranslated) {
		
		ResourceBundle destinationsFrom = ResourceBundle.getBundle("locations", validateLocale(localeFrom));
		ResourceBundle destinationsTo = ResourceBundle.getBundle("locations", validateLocale(localeTo));
		
		String key="";
		String translation="";
		Enumeration<String> keysFromEnumeration = destinationsFrom.getKeys();
		ArrayList<String> keysFrom = Collections.list(keysFromEnumeration);
		
		for (String k : keysFrom) {
			if (destinationsFrom.getString(k).equals(toBeTranslated)) {
				translation =  destinationsTo.getString(k);
			}
			else {
				continue;
			}
		}
		
		return translation;
		
	}
	
	public static String formatDate(String parsingPattern, String formattingPattern, String toBeFormatted) {
		
		SimpleDateFormat simpleDateParser = (SimpleDateFormat) DateFormat.getDateInstance();
		SimpleDateFormat simpleDateFormatter = (SimpleDateFormat) DateFormat.getDateInstance();
		simpleDateParser.applyPattern(parsingPattern);
		simpleDateFormatter.applyPattern(formattingPattern);
		try {
			return simpleDateFormatter.format(simpleDateParser.parse(toBeFormatted));
		} catch (Exception exc) {
			System.out.println("Wystąpił problem z parsowaniem daty.");
			return null;
		}
	}
	
	public static String formatPrice(String localeFrom, String localeTo, String toBeFormatted) {
		
		NumberFormat priceParser = NumberFormat.getInstance(validateLocale(localeFrom));
		NumberFormat priceFormatter = NumberFormat.getInstance(validateLocale(localeTo));
		try {
			Double inputPriceParsed = (Double) priceParser.parse(toBeFormatted);
			return priceFormatter.format(inputPriceParsed);
		} catch (Exception exc) {
			System.out.println("Wystąpił problem z parsowaniem ceny");
			return null;
		}
	}
	
	public static Locale validateLocale(String locale) {
		
		/* statyczna metoda dokonująca weryfikacji podanego kodu lokalizacji */
		
		String[] parts = locale.split("_");
		switch (parts.length) {
		  	case 3: return new Locale(parts[0], parts[1], parts[2]);
		    case 2: return new Locale(parts[0], parts[1]);
		    case 1: return new Locale(parts[0]);
		    default: return new Locale(parts[0]);
		}
		
	}
	
}
