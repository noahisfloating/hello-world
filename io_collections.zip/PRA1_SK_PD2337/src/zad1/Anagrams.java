/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad1;

import java.io.*;
import java.util.*;

public class Anagrams {
	
	File file;
	ArrayList<String> allwords = new ArrayList();
	
	public Anagrams(String file) {
		this.file=new File(file);
		setAllWords();
	}
	
	public void setAllWords() {
		try {
		Scanner scan = new Scanner(file);
		while (scan.hasNext()) {
			allwords.add(scan.next());
		}
		scan.close();
		} catch (FileNotFoundException exc) {
			System.out.println("Nie znaleziono pliku.");
		}
	}
	
	public String getWord(int i) {
		return allwords.get(i);
	}

	
	private char[] sortWord(String str) {
		String s = str.toLowerCase();
		char[] charsOfWord = new char[s.length()];
		for (int i=0; i<s.length(); i++) {
			charsOfWord[i]=s.charAt(i);
		}
		Arrays.sort(charsOfWord);
		return charsOfWord;
	}
	
	private boolean compare(char[] c1, char[] c2) {
		int result=0;
		if (c1.length == c2. length) {
			for (int i=0; i<c1.length; i++) {
				if (c1[i] == c2[i]) continue;
				else result++; break;
			}
		} else return false;
		if (result == 0) return true;
		else return false;
	}
	
	public String getAnagramsFor(String word) {
		ArrayList<String> anagrams = new ArrayList();
		boolean isContaining = false;
		char[] c1 = sortWord(word);
		for (String s : allwords) {
			if (word.toLowerCase().equals(s.toLowerCase())) isContaining = true;
			if (compare(c1, sortWord(s)) == true && !word.toLowerCase().equals(s.toLowerCase())) anagrams.add(s);
			else continue;
		}
		if (isContaining) return word + ": " + anagrams.toString();
		else return word + ": null";
	}
	
	public ArrayList<ArrayList<String>> getSortedByAnQty() {
		ArrayList<ArrayList<String>> list = new ArrayList();
		ArrayList<String> anagrams = new ArrayList();
		ArrayList<String> checked = new ArrayList();
		for (String str : allwords) {
			if (checked.contains(str)) continue;
			char[] c1 = sortWord(str);
			anagrams.clear();
			for (String s : allwords) {
			if (compare(c1, sortWord(s)) == true)
				{
				anagrams.add(s);
				checked.add(s);
				}
			else continue;
			}
			list.add((ArrayList<String>) anagrams.clone());
			Collections.sort(list, new Comparator<ArrayList>() {
				public int compare(ArrayList b, ArrayList a) {
					if (a.size()-b.size()!=0) {
					return a.size()-b.size();
					} else {
						return b.get(0).toString().compareTo(a.get(0).toString());
					}
				}
			});
		}
		return list;
	}
	
	
	
}  
