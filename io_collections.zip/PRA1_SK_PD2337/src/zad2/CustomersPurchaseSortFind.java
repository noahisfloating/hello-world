/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad2;

import java.util.*;
import java.io.*;

public class CustomersPurchaseSortFind {
	
	private ArrayList<Purchase> purchases = new ArrayList();
	
	private File file;
	
	public CustomersPurchaseSortFind() {
	
		
	}
	
	public void readFile(String fname) {
		try {
		 file = new File(fname);
		Scanner scan = new Scanner(file);
		StringBuffer sb = new StringBuffer();
		while (scan.hasNextLine()) {
			sb.append(scan.nextLine()+"\n");
		}
		StringTokenizer st = new StringTokenizer(sb.toString(), ";\n");
		while (st.hasMoreTokens()) {
			purchases.add(new Purchase(st.nextToken(), st.nextToken(), st.nextToken(), Double.parseDouble(st.nextToken()), Double.parseDouble(st.nextToken())));
		}
		} catch (FileNotFoundException exc) {
			System.out.println("Nie znaleziono pliku.");
		}
		
	}
	
	public void showSortedBy(String choice) {
		if (choice == "Nazwiska") {
		Collections.sort(purchases, new Comparator<Purchase>() {
			public int compare(Purchase a, Purchase b) {
				if (!a.getClientName().equals(b.getClientName())) {
					return a.getClientName().compareTo(b.getClientName());					
				} else {
					return a.getClientId().compareTo(b.getClientId());
				}
			}
		});
		System.out.println(choice);
		for (Purchase p : purchases) {
			System.out.println(p.getClientId()+";"+p.getClientName()+";"+p.getProduct()+";"+p.getPrice()+";"+p.getAmount());
		}
		System.out.println();
		}
		if (choice == "Koszty") {
		Collections.sort(purchases, new Comparator<Purchase>() {
			public int compare(Purchase a, Purchase b) {
				if (a.getPrice()*a.getAmount()-b.getPrice()*b.getAmount()>0) {
					return -1;					
				} else if (a.getPrice()*a.getAmount()-b.getPrice()*b.getAmount()<0) {
					return 1;
				} else return a.getClientId().compareTo(b.getClientId());
			}
		});
		System.out.println(choice);
		for (Purchase p : purchases) {
			System.out.println(p.getClientId()+";"+p.getClientName()+";"+p.getProduct()+";"+p.getPrice()+";"+p.getAmount()+ " (koszt: " + p.getPrice()*p.getAmount() + ")");
		}
		System.out.println();
		}
	}
	
	public void showPurchaseFor(String arg)
	{
		try {
			purchases.clear();
			Scanner scan = new Scanner(file);
			StringBuffer sb = new StringBuffer();
			while (scan.hasNextLine()) {
				sb.append(scan.nextLine()+"\n");
			}
			StringTokenizer st = new StringTokenizer(sb.toString(), ";\n");
			while (st.hasMoreTokens()) {
				purchases.add(new Purchase(st.nextToken(), st.nextToken(), st.nextToken(), Double.parseDouble(st.nextToken()), Double.parseDouble(st.nextToken())));
			}
			} catch (FileNotFoundException exc) {
				System.out.println("Nie znaleziono pliku.");
			}
			System.out.println("Klient " + arg);
			for (Purchase p : purchases) {
				if (p.getClientId().equals(arg)) System.out.println(p);
				else continue;
			}
			System.out.println();
	}
	
}
