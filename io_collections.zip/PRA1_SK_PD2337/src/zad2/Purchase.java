/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad2;


public class Purchase {
	
	private String clientId;
	private String clientName;
	private String product;
	private double price;
	private double amount;
	
	public Purchase (String clientId, String clientName, String product, double price, double amount) {
		this.clientId=clientId;
		this.clientName=clientName;
		this.product=product;
		this.price=price;
		this.amount=amount;
	}
	
	public String getClientId() {
		return clientId;
	}
	
	public String getClientName() {
		return clientName;
	}
	
	public String getProduct() {
		return product;
	}
	
	public double getPrice() {
		return price;
	}
	
	public double getAmount() {
		return amount;
	}
	
	public String toString() {
		return clientId + ";" + clientName + ";" + product + ";" + price + ";" + amount;
	}
	
}
