/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;



public class Main extends JFrame {
	
	private int i=0;
	private Color[] colors = {Color.WHITE, Color.BLUE, Color.MAGENTA, Color.CYAN};
	
	public Main() {
		super("Button changes color");
		final JButton b = new JButton("Change color");
		add(b);
		this.setLayout(new FlowLayout());
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.pack();
		this.setVisible(true);
		b.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if (i!=colors.length-1) i++;
				else i=0;
				b.setBackground(colors[i]);
			}
			
		});
	}
	
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				// TODO Auto-generated method stub
				new Main();
			}
			
		});
		
	}


}
