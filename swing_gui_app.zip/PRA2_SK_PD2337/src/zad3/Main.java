/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad3;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.*;

public class Main extends JFrame implements ActionListener {
	
	final JTextArea ta = new JTextArea();
	
	public Main() {
		
		super();
		

		JMenuBar mb = new JMenuBar();
		ArrayList<JMenuItem> fileItems = createMenuItems("New", "Open", "Save", "Save As", "Close");
		ArrayList<JMenuItem> addressItems = createMenuItems("Praca", "Szkoła", "Dom");
		ArrayList<JMenuItem> editItems = createMenuItems();
		ArrayList<JMenuItem> foregroundItems = createMenuItems("Blue", "Yellow", "Orange", "Red", "White", "Black", "Green");
		ArrayList<JMenuItem> backgroundItems = createMenuItems("Blue", "Yellow", "Orange", "Red", "White", "Black", "Green");
		ArrayList<JMenuItem> fontSizeItems = createMenuItems("8 pts", "10 pts", "12 pts", "14 pts", "16 pts", "18 pts", "20 pts", "22 pts");
		ArrayList<JMenuItem> optionsItems = createMenuItems();
		
		setColorProperties(foregroundItems);
		setColorProperties(backgroundItems);
		setFontSizeProperties(fontSizeItems);
		
		for(JMenuItem i : foregroundItems) i.setActionCommand("");
		for(JMenuItem i : backgroundItems) i.setActionCommand("");
		for(JMenuItem i : fontSizeItems) i.setActionCommand("");

		JMenu fileMenu = createMenu("File", fileItems);
		JMenu addressMenu = createMenu("Address", addressItems);
		JMenu editMenu = createMenu("Edit", editItems);
		JMenu foregroundMenu = createMenu("Foreground",  foregroundItems);
		JMenu backgroundMenu = createMenu("Background", backgroundItems);
		JMenu fontSizeMenu = createMenu("Font size", fontSizeItems);
		JMenu optionsMenu = createMenu("Options", optionsItems);
		

		editMenu.add(addressMenu);
		
		optionsMenu.add(foregroundMenu);
		optionsMenu.add(backgroundMenu);
		optionsMenu.add(fontSizeMenu);

		
		String fileName = "bez tytułu";
	
		Dimension d = new Dimension(500,500);
		
		this.setTitle("Prosty edytor - " + fileName);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setLayout(new GridLayout(1,1));
		mb.add(fileMenu);
		mb.add(editMenu);
		mb.add(optionsMenu);

		this.add(mb);
		this.setJMenuBar(mb);
		//this.add(b);
		JScrollPane sp = new JScrollPane(ta);
		this.add(sp);
		this.setPreferredSize(d);
		this.pack();
		this.setVisible(true);
		
	}
	
	public ArrayList<JMenuItem> createMenuItems(String ... items) {
		ArrayList<JMenuItem> jmi = new ArrayList<JMenuItem>();
		for (String s : items) {
			JMenuItem mi = new JMenuItem(s);
			mi.addActionListener(this);
			jmi.add(mi);
		}
		return jmi;
	}
	
	public JMenu createMenu(String title, ArrayList<JMenuItem> items) {
		JMenu jm = new JMenu(title);
		for (JMenuItem i : items) {
			JMenuItem mi=i;
			mi.setActionCommand(title+mi.getActionCommand());
			jm.add(mi);
		}
		return jm;
	}
	
	public void setColorProperties(ArrayList<JMenuItem> items)
	{
		Color[] colors = {Color.BLUE, Color.YELLOW, Color.ORANGE, Color.RED, Color.WHITE, Color.BLACK, Color.GREEN};
		for (int i=0; i<items.size(); i++) {
			items.get(i).putClientProperty("Color", colors[i]);
		}
	}
	
	public void setFontSizeProperties(ArrayList<JMenuItem> items)
	{
		Integer[] sizes = {8, 10, 12, 14, 16, 18, 20, 22, 24};
		for (int i=0; i<items.size(); i++) {
			items.get(i).putClientProperty("Font Size", sizes[i]);
		}
	}
	
  public static void main(String[] args) {
	  
	  SwingUtilities.invokeLater(new Runnable() {

		public void run() {
			// TODO Auto-generated method stub
			new Main();
		}
		  
	  });
	  
  }

public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	String cmd = e.getActionCommand();
	
	// "Blue", "Yellow", "Orange", "Red", "White", "Black", "Green"
	
	if (cmd.equals("AddressPraca")) doAdressPraca();
	else if (cmd.equals("AddressSzkoła")) doAddressSzkoła();
	else if (cmd.equals("AddressDom")) doAddressDom();
	else if (cmd.equals("Foreground")) doChangeForeground(e);
	else if (cmd.equals("Background")) doChangeBackground(e);
	else if (cmd.equals("Font size")) doChangeFontSize(e);
	else if (cmd.equals("FileNew")) doFileNew();
	else if (cmd.equals("FileOpen")) doFileOpen();
}



private void doFileNew() {
	// TODO Auto-generated method stub
	this.getTextArea().setText("");
}

private void doFileOpen() {
	// TODO Auto-generated method stub
	JFileChooser fc = new JFileChooser();
	fc.showOpenDialog(null);
	File file = fc.getSelectedFile();
	try {
	Scanner scan = new Scanner(file);
	while (scan.hasNextLine()) this.getTextArea().append(scan.nextLine()+"\n");
	scan.close();
	} catch (FileNotFoundException exc) {
		JOptionPane.showOptionDialog(null, "Nie znaleziono pliku", "Błąd", JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, null, null);
	}
}

private void doChangeFontSize(ActionEvent e) {
	// TODO Auto-generated method stub
	JComponent src = (JComponent) e.getSource();
	Integer size = (Integer) src.getClientProperty("Font Size");
	this.getTextArea().setFont(new Font("Font", Font.PLAIN, size.intValue()));
}

private void doChangeBackground(ActionEvent e) {
	// TODO Auto-generated method stub
	JComponent src = (JComponent) e.getSource();
	Color color = (Color) src.getClientProperty("Color");
	this.getTextArea().setBackground(color);
}

private void doChangeForeground(ActionEvent e) {
	// TODO Auto-generated method stub
	JComponent src = (JComponent) e.getSource();
	Color color = (Color) src.getClientProperty("Color");
	this.getTextArea().setForeground(color);
}

private void doAddressDom() {
	// TODO Auto-generated method stub
	this.getTextArea().append("ul. Szwejka 61/2, 20-713 Lublin");
}

private void doAddressSzkoła() {
	// TODO Auto-generated method stub
	this.getTextArea().append("ul. Nadbystrzycka 38D, 20-001 Lublin");
}

private void doAdressPraca() {
	// TODO Auto-generated method stub
	this.getTextArea().append("ul. Lubelska 41, 08-500 Ryki");
}

public JTextArea getTextArea() {
	return ta;
}



}
