/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;

import javax.swing.*;


public class Main extends JFrame {

  public Main() {
	  
	  super("Labels");
	  int i=0;
	  JLabel[] labels = {new JLabel("Pierwszy", JLabel.CENTER), new JLabel("Drugi", JLabel.CENTER), new JLabel("Trzeci", JLabel.CENTER), 
			  new JLabel("Czwarty", JLabel.CENTER), new JLabel("Piąty", JLabel.CENTER)};
	  String[] locations = {"West", "North", "East", "South", "Center"};
	  Color[] backgroundColors = {Color.YELLOW, Color.WHITE, Color.RED, Color.PINK, Color.ORANGE};
	  Color[] fontColors = {Color.BLACK, Color.BLUE, Color.CYAN, Color.DARK_GRAY, Color.GREEN};
	  Container cont = this.getContentPane();
	  cont.setLayout(new BorderLayout());
	  for (int j=0; j<labels.length; j++) {
		  cont.add(labels[j], locations[j]);
		  labels[j].setOpaque(true);
		  labels[j].setBackground(backgroundColors[j]);
		  labels[j].setForeground(fontColors[j]);
		  labels[j].setFont(new Font("Label", Font.BOLD, 10*(j+1)));
		  labels[j].setToolTipText(labels[j].getText());
		  labels[j].setBorder(BorderFactory.createLineBorder(fontColors[j], 5*(j+1)));
	  }
	  this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	  this.setLocationRelativeTo(null);
	  this.pack();
	  this.setVisible(true);	  
  }
	
  public static void main(String[] args) {
	  
	  SwingUtilities.invokeLater(new Runnable() {

		public void run() {
			// TODO Auto-generated method stub
			new Main();
		}
		  
	  });
	  
  }
}

