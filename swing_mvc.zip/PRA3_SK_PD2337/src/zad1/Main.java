/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad1;

import javax.swing.*;

import java.text.DecimalFormat;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Main extends JFrame implements ActionListener {

    public Main() {
    	
    	super("JList1");
    	JList l1 = new JList(new AbstractListModel() {
    		public Object getElementAt(int i) { 
    			double c = -70.0+i;
    			double f = 32+9.0/5*c;
    			DecimalFormat df = new DecimalFormat("0.00");
    			return df.format(c) + " stopni C = " + df.format(f) + " stopni F"; }
    		public int getSize() { return 131; }
    		});
    	JScrollPane sp = new JScrollPane(l1);
    	// l1.setPreferredSize(new Dimension(200, 3000));
    	java.awt.Container cont = this.getContentPane();
    	cont.setLayout(new BorderLayout());
    	this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    	this.setLocationRelativeTo(null);
    	// this.setBounds(200, 200, 250, 250);
    	this.setVisible(true);
    	cont.add(sp, "Center");
    	this.pack();
     }
	
	public static void main(String[] args) {
	  
	  SwingUtilities.invokeLater(new Runnable() {

		public void run() {
			// TODO Auto-generated method stub
			new Main();
		}
		  
	  });
	  
  }

public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
	
	
}
}
