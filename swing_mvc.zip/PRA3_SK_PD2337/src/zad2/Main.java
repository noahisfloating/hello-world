/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad2;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.AbstractListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;


class MyListModel extends AbstractListModel {
	
	Vector v = new Vector();
	
	public MyListModel() {}
	
	public MyListModel(Object[] o) {
		for (int i=0; i<o.length; i++) v.addElement(o[i]);
	}

	public Object getElementAt(int arg0) {
		// TODO Auto-generated method stub
		return v.elementAt(arg0);
	}

	public int getSize() {
		// TODO Auto-generated method stub
		return v.size();
	}
	
	public void add(int index, Object o) {
		v.insertElementAt(o, index);
		fireIntervalAdded(this, index, index);
	}
	
	public void add(Object o) {
		add(getSize(), o);
	}
	
	public void remove(int index) {
		v.removeElementAt(index);
		fireIntervalRemoved(this, index, index);
	}
	
}

public class Main extends JFrame implements KeyListener, MouseListener {

	MyListModel mlm = new MyListModel();
	
	Container c = this.getContentPane();
	JTextField tf = new JTextField();
	JList l = new JList(mlm);
	JScrollPane sp = new JScrollPane(l);
	
	public Main() {
		
		super("JList2");
		
		c.setLayout(new BorderLayout());
		c.add(tf, "North");
		c.add(sp, "Center");
		
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(200,200,500,500);
		this.setLocationRelativeTo(null);
		this.pack();
		this.setVisible(true);
		tf.addKeyListener(this);
		l.addMouseListener(this);
		
	}
  
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				// TODO Auto-generated method stub
				new Main();
			}
			
		});
		
    }

	public void keyPressed(KeyEvent k) {
		// TODO Auto-generated method stub
		KeyEvent ke = k;
		int keyCode = ke.getKeyCode();
		String text = tf.getText();
		if (keyCode == KeyEvent.VK_ENTER) {
			mlm.add(text);
		}
	}

	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
	public void mouseClicked(MouseEvent m) {
		// TODO Auto-generated method stub
		MouseEvent me = m;
		boolean isAltDown = m.isAltDown();
		int i = l.getSelectedIndex();
		if (isAltDown) mlm.remove(i);		
	}


	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
