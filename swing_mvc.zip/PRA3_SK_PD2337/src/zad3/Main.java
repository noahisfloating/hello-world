/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad3;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;


class Book {
	
	private String author;
	private String title;
	private Double price;
	private File coverImage;
	
	public Book(String author, String title, Double price, File coverImage) {
		this.author = author;
		this.title = title;
		this.price = price;
		this.coverImage = coverImage;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public String getTitle() {
		return title;
	}
	
	public Double getPrice() {
		return price;
	}
	
	public File getCoverImage() {
		return coverImage;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setPrice(Double price) {
		this.price = price;
	}
	
	public void setCoverImage(File coverImage) {
		this.coverImage = coverImage;
	}
	
	public String toString() {
		return (this.author + "---" + this.title + "---" + this.price.toString() + "---" + this.coverImage.getName());
	}
}

class MyImageIcon extends ImageIcon {
	
	String temp;
	
	public MyImageIcon(String s) {
		super(s);
		temp=s;
	}
	
	public String toString() {
		return (new File(temp).getName());
	}
	
}

class MyTableModel extends AbstractTableModel {
	
	private String[] columnNames = {"Autor", "Tytuł", "Cena", "Okładka"};
	private ArrayList<Book> tableData;
	
	public MyTableModel(String[] columnNames, ArrayList<Book> tableData) {
		this.columnNames = columnNames;
		this.tableData = tableData;
	}
	
	public String getColumnName(int column) {
		return columnNames[column];
	}

	public int getColumnCount() {
		// TODO Auto-generated method stub
		return columnNames.length;
	}

	public int getRowCount() {
		// TODO Auto-generated method stub
		return tableData.size();
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		switch (columnIndex) {
		case 0: return (Object) tableData.get(rowIndex).getAuthor();
		case 1: return (Object) tableData.get(rowIndex).getTitle();
		case 2: return (Object) tableData.get(rowIndex).getPrice();
		case 3:	MyImageIcon icon = new MyImageIcon(tableData.get(rowIndex).getCoverImage().getAbsolutePath());
				return icon;
		default: return null;
		}
	}
	
	public void setValueAt(Object o, int rowIndex, int columnIndex) {
		try {
			switch (columnIndex) {
			case 0: tableData.get(rowIndex).setAuthor((String) o);
					fireTableCellUpdated(rowIndex, columnIndex);
					break;
			case 1: tableData.get(rowIndex).setTitle((String) o);
					fireTableCellUpdated(rowIndex, columnIndex);
					break;
			case 2: tableData.get(rowIndex).setPrice((Double) o);
					fireTableCellUpdated(rowIndex, columnIndex);
					break;
			case 3: tableData.get(rowIndex).setCoverImage((File) o);
					fireTableCellUpdated(rowIndex, columnIndex);
					break;
			}
		} catch (Exception exc) {}
	}
	
	public Class getColumnClass(int column) {
		return getValueAt(0, column).getClass();
	}
	
	public void addRow(Book book) {
		int rowCount = this.getRowCount();
		tableData.add(book);
		this.fireTableRowsInserted(rowCount, rowCount+1);
	}
	
	public void deleteRow(int rowIndex) {
		tableData.remove(rowIndex);
		this.fireTableRowsDeleted(rowIndex, rowIndex+1);
	}
	
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		if (columnIndex == 2) return true;
		else return false;
	}
	
	public ArrayList<Book> getTableData() {
		return this.tableData;
	}
	
	public String toString() {
		try {
			StringBuffer sb = new StringBuffer();
			for (int i=0; i<this.getRowCount(); i++) {
				sb.append(this.getTableData().get(i).toString());
				if (i != this.getRowCount()-1) sb.append(System.getProperty("line.separator"));
				else break;
			}
			return sb.toString();
		} catch (Exception exc) {
			return null;
		}
	}

}


public class Main extends JFrame implements TableModelListener, ActionListener {
	
	private MyTableModel mtm;
	private File currentFile;
	
	private JTable tab;
	private JLabel authorLabel;
	private JTextField authorTextField;
	private JLabel titleLabel;
	private JTextField titleTextField;
	private JLabel priceLabel;
	private JTextField priceTextField;
	private JLabel coverImageLabel;
	private JTextField coverImageTextField;
	
	public Main() {
		
		super("JTable");
	
		String[] columns = {"Author", "Title", "Price", "Cover"};
		
		currentFile = new File("books.txt");
		
		mtm = new MyTableModel(columns, readFile(currentFile/*new File(System.getProperty("user.home")+"/books.txt")*/));
		tab = new JTable(mtm);
		
        JScrollPane sp = new JScrollPane(tab);
        Container c = this.getContentPane();
        Container controller = new Container();
        c.setLayout(new BorderLayout());
        controller.setLayout(new FlowLayout());
		
		mtm.addTableModelListener(this);
        
		authorLabel = new JLabel("Author:");
		authorTextField = new JTextField(10);
		titleLabel = new JLabel("Title:");
		titleTextField = new JTextField(10);
		priceLabel = new JLabel("Price:");
		priceTextField = new JTextField(10);
		coverImageLabel = new JLabel("Cover Image:");
		coverImageTextField = new JTextField(10);
		
		KeyListener addRowKeyListener = new KeyListener() {

			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub
				if (arg0.getKeyCode()==KeyEvent.VK_ENTER) {
				try {
					getMyTableModel().addRow(new Book(authorTextField.getText(), titleTextField.getText(), Double.parseDouble(priceTextField.getText()), new File(System.getProperty("user.home")+"/"+coverImageTextField.getText())));
					authorTextField.setText(null);
					titleTextField.setText(null);
					priceTextField.setText(null);
					coverImageTextField.setText(null);
					authorTextField.requestFocus();
				} catch (Exception exc) {
					JOptionPane.showMessageDialog(null, "Nie udało się dodać kolejnej książki. Popraw dane wejściowe.", "Uwaga!", JOptionPane.INFORMATION_MESSAGE);
				}
				}
			}
			

			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			public void keyTyped(KeyEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
		};
		
		KeyListener deleteRowKeyListener = new KeyListener() {

			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub
				if (arg0.getKeyCode()==KeyEvent.VK_ENTER) {
					try {
						getMyTableModel().deleteRow(tab.getSelectedRow());
					} catch (Exception exc) {
						JOptionPane.showMessageDialog(null, "Nie udało się usunąć żadnego wiersza.", "Uwaga!", JOptionPane.INFORMATION_MESSAGE);
					}	
				}
			}

			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			public void keyTyped(KeyEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
		};
		
        JButton addRowButton = new JButton("Add Row");
        addRowButton.setActionCommand("Add Row");
        addRowButton.addActionListener(this);
        addRowButton.addKeyListener(addRowKeyListener);
        
        JButton deleteRowButton = new JButton("Delete Row");
        deleteRowButton.setActionCommand("Delete Row");
        deleteRowButton.addActionListener(this);
        deleteRowButton.addKeyListener(deleteRowKeyListener);
        
        controller.add(authorLabel);
        controller.add(authorTextField);
        controller.add(titleLabel);
        controller.add(titleTextField);
        controller.add(priceLabel);
        controller.add(priceTextField);
        controller.add(coverImageLabel);
        controller.add(coverImageTextField);
        controller.add(addRowButton);
        controller.add(deleteRowButton);
        c.add(controller, "North");
        c.add(sp, "Center");
        
        tab.setRowHeight(300);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setBounds(100, 100, 900, 900);
		this.setVisible(true);	
	}

	public MyTableModel getMyTableModel() {
		return mtm;
	}
	
	public ArrayList<Book> readFile(File f) {
		currentFile = f;
		try {
		String line;
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		ArrayList<Book> booksData = new ArrayList();
		while ((line = br.readLine()) != null) {
			String[] bookPrototype = line.split("---");
			booksData.add(new Book(bookPrototype[0], bookPrototype[1], Double.parseDouble(bookPrototype[2]), new File(/*f.getParent()+"/"+*/bookPrototype[3])));
		}
		fr.close();
		return booksData;
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Błąd odczytu pliku.", "Uwaga!", JOptionPane.INFORMATION_MESSAGE);
			return null;
		}
	}
	
	/* CZY NIE NALEŻAŁOBY PRZENIEŚĆ TEJ METODY DO KLASY MODELU DANYCH TABELI? */
	

	
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				// TODO Auto-generated method stub
				new Main();
			}
			
		});
		
	}

	public void tableChanged(TableModelEvent tme) {
		// TODO Auto-generated method stub
		MyTableModel tm = (MyTableModel) tme.getSource();
		try {
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(currentFile)));
		bw.write(this.getMyTableModel().toString());
		bw.close();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Nie udało się zapisać pliku", "Uwaga!", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand()=="Add Row") {
		try {
			getMyTableModel().addRow(new Book(authorTextField.getText(), titleTextField.getText(), Double.parseDouble(priceTextField.getText()), new File(System.getProperty("user.home")+"/"+coverImageTextField.getText())));
			authorTextField.setText(null);
			titleTextField.setText(null);
			priceTextField.setText(null);
			coverImageTextField.setText(null);
			authorTextField.requestFocus();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Nie udało się dodać kolejnej książki. Popraw dane wejściowe.", "Uwaga!", JOptionPane.INFORMATION_MESSAGE);
		}
		} else if (e.getActionCommand()=="Delete Row") {
		try {
			getMyTableModel().deleteRow(tab.getSelectedRow());
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Nie udało się usunąć żadnego wiersza.", "Uwaga!", JOptionPane.INFORMATION_MESSAGE);
		}
		}
	}
}
