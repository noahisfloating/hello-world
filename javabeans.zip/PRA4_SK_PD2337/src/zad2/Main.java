/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad2;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;


public class Main {
  public static void main(String[] args) {

    Purchase purch = new Purchase("komputer", "nie ma promocji", 3000.00);
    System.out.println(purch);

    purch.addPropetyChangeListener(purch);

    purch.addVetoableChangeListener(new VetoableChangeListener() {

		public void vetoableChange(PropertyChangeEvent pce)
				throws PropertyVetoException {
			// TODO Auto-generated method stub
			Double newValue = (Double) pce.getNewValue();
			double doubleNewValue = newValue.doubleValue();
			if (pce.getPropertyName() == "price" &&  doubleNewValue<1000.0) {
				throw new PropertyVetoException("Price change to: " + pce.getNewValue() + " not allowed", pce);
			}
		}
    	
    });

    try {
      purch.setData("w promocji");
      purch.setPrice(2000.00);
      System.out.println(purch);

      purch.setPrice(500.00);

    } catch (PropertyVetoException exc) {
      System.out.println(exc.getMessage());
    }
    System.out.println(purch);

  }
}
