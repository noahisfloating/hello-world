/**
 *
 *  @author Staszewski Kamil PD2337
 *
 */

package zad1;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.HashMap;


public class Calc {
	
	Class c;
	HashMap hm;

	public Calc() {
		
		try {
			Class c = Class.forName("java.math.BigDecimal");
			hm = new HashMap();
			hm.put("+", c.getMethod("add", c));
			hm.put("-", c.getMethod("subtract", c));
			hm.put("*", c.getMethod("multiply", c));
			hm.put("/", c.getMethod("divide", c, MathContext.class));
		} catch (Exception exc) {
			System.out.println("Nie udało się utworzyć kalkulatora");
		}
		
	}
	
	public String doCalc(String cmd) {
		MathContext mc = new MathContext(7);
		BigDecimal a = null;
		BigDecimal b = null;
		Method m = null;
		BigDecimal result = null;
		try {
			String[] data = cmd.split("\\s+");
			a = new BigDecimal(data[0]);
			b = new BigDecimal(data[2]);
			m  = (Method) hm.get(data[1]);
			result = (BigDecimal) m.invoke(a, b);
			return result.toString();
		} catch (Exception exc) {
			try {
				String[] data = cmd.split("\\s+");
				a = new BigDecimal(data[0]);
				b = new BigDecimal(data[2]);
				m  = (Method) hm.get(data[1]);
				result = (BigDecimal) m.invoke(a, b, mc);
				return result.toString();
			} catch (Exception exc1) {
				return "Invalid command to calc";
			}
			// return "Invalid command to calc";	
		}
	}
	
}  
